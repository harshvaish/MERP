(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["icon-keys-icon-keys-module"],{

/***/ "./src/app/icon-keys/icon-keys.module.ts":
/*!***********************************************!*\
  !*** ./src/app/icon-keys/icon-keys.module.ts ***!
  \***********************************************/
/*! exports provided: IconKeysPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconKeysPageModule", function() { return IconKeysPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _icon_keys_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./icon-keys.page */ "./src/app/icon-keys/icon-keys.page.ts");







var routes = [
    {
        path: '',
        component: _icon_keys_page__WEBPACK_IMPORTED_MODULE_6__["IconKeysPage"]
    }
];
var IconKeysPageModule = /** @class */ (function () {
    function IconKeysPageModule() {
    }
    IconKeysPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_icon_keys_page__WEBPACK_IMPORTED_MODULE_6__["IconKeysPage"]]
        })
    ], IconKeysPageModule);
    return IconKeysPageModule;
}());



/***/ }),

/***/ "./src/app/icon-keys/icon-keys.page.html":
/*!***********************************************!*\
  !*** ./src/app/icon-keys/icon-keys.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\" ><ion-icon name=\"home\" routerLink=\"/home\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title left>\n       Arodek\n      </ion-title>\n      <ion-buttons slot=\"end\">\n          <button class=\"home-icon\" routerLink=\"/icon-keys\" > <ion-icon name=\"help-circle\"></ion-icon> </button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" ><ion-icon name=\"filing\"></ion-icon></button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\"  routerLink=\"/update-profile\" ><ion-icon name=\"person\"></ion-icon></button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" routerLink=\"/login\"  ><ion-icon name=\"power\"></ion-icon></button>\n      </ion-buttons>\n      \n        \n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n                <ion-col></ion-col>\n            \n                <ion-col>\n                        <h3>Icon Keys</h3>\n              </ion-col>\n              <ion-col>\n                  <h3><ion-icon name=\"close\"  routerLink=\"/home\"></ion-icon></h3>\n                </ion-col>\n                  </ion-row>\n       <ion-row>\n             <ion-col size=\"4\">\n                    <ion-icon class=\"icon-key\" name=\"home\"></ion-icon>\n             </ion-col>\n             <ion-col size=\"8\">\n             \n               <p><strong>Home Button -</strong> Display the available Emergency PLans based on Group Assignment.</p>\n              </ion-col>\n          </ion-row>\n          <ion-row>\n                <ion-col size=\"4\">\n                       <ion-icon class=\"icon-key\" name=\"settings\"></ion-icon>\n                </ion-col>\n                <ion-col size=\"8\">\n                \n                  <p><strong>Adminstrative Setting -</strong> Provide Access to Adminstrative options.</p>\n                 </ion-col>\n             </ion-row>\n      \n             <ion-row>\n                    <ion-col size=\"4\">\n                           <ion-icon class=\"icon-key\" name=\"power\"></ion-icon>\n                    </ion-col>\n                    <ion-col size=\"8\">\n                    \n                      <p><strong>Sign Out -</strong> Signs the User out of the MERP system.</p>\n                     </ion-col>\n                 </ion-row>\n      \n                 <ion-row>\n                        <ion-col size=\"4\">\n                               <ion-icon class=\"icon-key\" name=\"warning\"></ion-icon>\n                        </ion-col>\n                        <ion-col size=\"8\">\n                        \n                          <p><strong>Incident Icon -</strong>Incident which events is currently selected.</p>\n                         </ion-col>\n                     </ion-row>\n      \n                     <ion-row>\n                            <ion-col size=\"4\">\n                                   <ion-icon class=\"icon-key\" name=\"filing\"></ion-icon>\n                            </ion-col>\n                            <ion-col size=\"8\">\n                            \n                              <p><strong>Support files -</strong> Access to any supporting files that have been uploaded.</p>\n                             </ion-col>\n                         </ion-row>\n                         <ion-row>\n                                <ion-col size=\"4\">\n                                       <ion-icon class=\"icon-key\" name=\"browsers\"></ion-icon>\n                                </ion-col>\n                                <ion-col size=\"8\">\n                                \n                                  <p><strong>Overview  -</strong> Displays a flow chart overview of the incident selected,  </p>\n                                 </ion-col>\n                             </ion-row>\n                             <ion-row>\n                                    <ion-col size=\"4\">\n                                           <ion-icon class=\"icon-key bg-black\"  name=\"filing\"></ion-icon>\n                                    </ion-col>\n                                    <ion-col size=\"8\">\n                                    \n                                      <p><strong>Event Aid -</strong> Offers more information specific to the incident selected.</p>\n                                     </ion-col>\n                                 </ion-row>\n                                 <ion-row>\n                                        <ion-col size=\"4\">\n                                               <ion-icon class=\"icon-key\" name=\"list-box\"></ion-icon>\n                                        </ion-col>\n                                        <ion-col size=\"8\">\n                                        \n                                          <p><strong>Incident Log -</strong> Displays the incident log with the ability to add in additional notes.</p>\n                                         </ion-col>\n                                     </ion-row>\n                                     <ion-row>\n                                            <ion-col size=\"4\">\n                                                   <ion-icon class=\"icon-key\" name=\"close\"></ion-icon>\n                                            </ion-col>\n                                            <ion-col size=\"8\">\n                                            \n                                              <p><strong>Close -</strong> Close the Current Window and return the user to the home dashboard.</p>\n                                             </ion-col>\n                                         </ion-row>\n                                                             \n    </ion-grid>      \n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/icon-keys/icon-keys.page.scss":
/*!***********************************************!*\
  !*** ./src/app/icon-keys/icon-keys.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.icon-key {\n  padding: 20px;\n  font-size: 30px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaWNvbi1rZXlzL0Q6XFxpb25pY19wcm9qZWN0XFxNRVJQXFxtZXJwL3NyY1xcYXBwXFxpY29uLWtleXNcXGljb24ta2V5cy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFXLGFBQWE7RUFBRSxlQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9pY29uLWtleXMvaWNvbi1rZXlzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7IGJhY2tncm91bmQ6ICMwMzE2MzcgIWltcG9ydGFudDt9XHJcbi5ob21lLWljb257ICAgIGNvbG9yOiAjZmZmO2JhY2tncm91bmQ6IG5vbmU7Zm9udC1zaXplOiAyNnB4O31cclxuLmljb24ta2V5eyBwYWRkaW5nOiAyMHB4OyBmb250LXNpemU6IDMwcHg7fVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/icon-keys/icon-keys.page.ts":
/*!*********************************************!*\
  !*** ./src/app/icon-keys/icon-keys.page.ts ***!
  \*********************************************/
/*! exports provided: IconKeysPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconKeysPage", function() { return IconKeysPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var IconKeysPage = /** @class */ (function () {
    function IconKeysPage() {
    }
    IconKeysPage.prototype.ngOnInit = function () {
    };
    IconKeysPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-icon-keys',
            template: __webpack_require__(/*! ./icon-keys.page.html */ "./src/app/icon-keys/icon-keys.page.html"),
            styles: [__webpack_require__(/*! ./icon-keys.page.scss */ "./src/app/icon-keys/icon-keys.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], IconKeysPage);
    return IconKeysPage;
}());



/***/ })

}]);
//# sourceMappingURL=icon-keys-icon-keys-module.js.map