(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["update-profile-update-profile-module"],{

/***/ "./src/app/update-profile/update-profile.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/update-profile/update-profile.module.ts ***!
  \*********************************************************/
/*! exports provided: UpdateProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateProfilePageModule", function() { return UpdateProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _update_profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./update-profile.page */ "./src/app/update-profile/update-profile.page.ts");







var routes = [
    {
        path: '',
        component: _update_profile_page__WEBPACK_IMPORTED_MODULE_6__["UpdateProfilePage"]
    }
];
var UpdateProfilePageModule = /** @class */ (function () {
    function UpdateProfilePageModule() {
    }
    UpdateProfilePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_update_profile_page__WEBPACK_IMPORTED_MODULE_6__["UpdateProfilePage"]]
        })
    ], UpdateProfilePageModule);
    return UpdateProfilePageModule;
}());



/***/ }),

/***/ "./src/app/update-profile/update-profile.page.html":
/*!*********************************************************!*\
  !*** ./src/app/update-profile/update-profile.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\"  routerLink=\"/home\" ><ion-icon name=\"home\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title>\n       Aerodek\n      </ion-title>\n      \n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" routerLink=\"/login\" > <ion-icon name=\"power\"></ion-icon> </button>\n      </ion-buttons>\n        \n    </ion-toolbar>\n  </ion-header>\n\n  \n<ion-content>\n    <ion-card  class=\"login-box\">\n        <ion-card-header class=\"login-heading\">\n           <ion-card-title  class=\"heading\" >Update Profile</ion-card-title>\n        </ion-card-header>\n      \n        <ion-card-content >\n            <p class=\"update\">Leave Password fields blank if you do not want to change your password. </p>\n            <ion-item class=\"form-control\">\n               <ion-input    placeholder=\"Email Address\"  ></ion-input>\n            </ion-item>\n          \n            <ion-item class=\"form-control\">\n                <ion-input type=\"password\" placeholder=\"Current Password\"  ></ion-input>\n            </ion-item>\n          \n            <ion-item class=\"form-control\">\n                <ion-input type=\"password\" placeholder=\" Password\"  ></ion-input>\n            </ion-item>\n            <ion-item class=\"form-control\">\n                <ion-input type=\"password\" placeholder=\" Password Confirmation\"  ></ion-input>\n            </ion-item>\n          \n            <div text-center margin-top>\n              <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                Update\n              </button>\n              \n           \n            </div>\n        </ion-card-content>\n      </ion-card>\n\n     \n \n</ion-content>\n<ion-footer>\n    <img src=\"assets/img/logo-merp.png\">\n\n\n    \n  </ion-footer> \n"

/***/ }),

/***/ "./src/app/update-profile/update-profile.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/update-profile/update-profile.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.login-heading {\n  background: #031637;\n  padding: 15px;\n  text-align: center;\n  line-height: 2; }\n\n.heading {\n  color: #fff;\n  font-size: 26px; }\n\n.form-control {\n  background: #fff;\n  margin-top: 15px; }\n\n.login-box {\n  background: #dde5fa;\n  margin-top: 10%; }\n\n.btn {\n  width: 100%;\n  padding: 10px;\n  background: #031637;\n  color: #fff;\n  height: 50px; }\n\n.update {\n  padding: 20px;\n  text-align: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXBkYXRlLXByb2ZpbGUvRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXHVwZGF0ZS1wcm9maWxlXFx1cGRhdGUtcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUUzRDtFQUFnQixtQkFBbUI7RUFBRSxhQUFhO0VBQUUsa0JBQWtCO0VBQUUsY0FBYyxFQUFBOztBQUN0RjtFQUFVLFdBQVU7RUFBRSxlQUFlLEVBQUE7O0FBQ3JDO0VBQWUsZ0JBQWdCO0VBQUUsZ0JBQWdCLEVBQUE7O0FBQ2pEO0VBQVksbUJBQW1CO0VBQUUsZUFBZSxFQUFBOztBQUNoRDtFQUFNLFdBQVc7RUFBRSxhQUFhO0VBQUUsbUJBQW1CO0VBQUUsV0FBVztFQUFFLFlBQVksRUFBQTs7QUFDaEY7RUFBVyxhQUFhO0VBQUUsa0JBQWtCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC91cGRhdGUtcHJvZmlsZS91cGRhdGUtcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyeyBiYWNrZ3JvdW5kOiAjMDMxNjM3ICFpbXBvcnRhbnQ7fVxyXG4uaG9tZS1pY29ueyAgICBjb2xvcjogI2ZmZjtiYWNrZ3JvdW5kOiBub25lO2ZvbnQtc2l6ZTogMjZweDt9XHJcblxyXG4ubG9naW4taGVhZGluZ3sgYmFja2dyb3VuZDogIzAzMTYzNzsgcGFkZGluZzogMTVweDsgdGV4dC1hbGlnbjogY2VudGVyOyBsaW5lLWhlaWdodDogMjt9XHJcbi5oZWFkaW5neyBjb2xvcjojZmZmOyBmb250LXNpemU6IDI2cHg7fVxyXG4uZm9ybS1jb250cm9seyBiYWNrZ3JvdW5kOiAjZmZmOyBtYXJnaW4tdG9wOiAxNXB4OyAgfVxyXG4ubG9naW4tYm94eyBiYWNrZ3JvdW5kOiAjZGRlNWZhOyBtYXJnaW4tdG9wOiAxMCU7fVxyXG4uYnRueyB3aWR0aDogMTAwJTsgcGFkZGluZzogMTBweDsgYmFja2dyb3VuZDogIzAzMTYzNzsgY29sb3I6ICNmZmY7IGhlaWdodDogNTBweDt9XHJcbi51cGRhdGV7ICAgcGFkZGluZzogMjBweDsgdGV4dC1hbGlnbjogY2VudGVyO30iXX0= */"

/***/ }),

/***/ "./src/app/update-profile/update-profile.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/update-profile/update-profile.page.ts ***!
  \*******************************************************/
/*! exports provided: UpdateProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateProfilePage", function() { return UpdateProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var UpdateProfilePage = /** @class */ (function () {
    function UpdateProfilePage() {
    }
    UpdateProfilePage.prototype.ngOnInit = function () {
    };
    UpdateProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-update-profile',
            template: __webpack_require__(/*! ./update-profile.page.html */ "./src/app/update-profile/update-profile.page.html"),
            styles: [__webpack_require__(/*! ./update-profile.page.scss */ "./src/app/update-profile/update-profile.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], UpdateProfilePage);
    return UpdateProfilePage;
}());



/***/ })

}]);
//# sourceMappingURL=update-profile-update-profile-module.js.map