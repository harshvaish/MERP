(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["files-files-module"],{

/***/ "./src/app/files/files.module.ts":
/*!***************************************!*\
  !*** ./src/app/files/files.module.ts ***!
  \***************************************/
/*! exports provided: FilesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilesPageModule", function() { return FilesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _files_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./files.page */ "./src/app/files/files.page.ts");







var routes = [
    {
        path: '',
        component: _files_page__WEBPACK_IMPORTED_MODULE_6__["FilesPage"]
    }
];
var FilesPageModule = /** @class */ (function () {
    function FilesPageModule() {
    }
    FilesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_files_page__WEBPACK_IMPORTED_MODULE_6__["FilesPage"]],
            exports: [
                _files_page__WEBPACK_IMPORTED_MODULE_6__["FilesPage"]
            ]
        })
    ], FilesPageModule);
    return FilesPageModule;
}());



/***/ }),

/***/ "./src/app/files/files.page.html":
/*!***************************************!*\
  !*** ./src/app/files/files.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\" routerLink=\"/home\"  ><ion-icon name=\"home\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title left>\n       Arodek\n      </ion-title>\n      <ion-buttons slot=\"end\">\n          <button class=\"home-icon\" routerLink=\"/icon-keys\" > <ion-icon name=\"help-circle\"></ion-icon> </button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" ><ion-icon name=\"filing\" routerLink=\"/files\"></ion-icon></button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\"  routerLink=\"/update-profile\"  ><ion-icon name=\"person\"></ion-icon></button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" routerLink=\"/login\" ><ion-icon name=\"power\"></ion-icon></button>\n      </ion-buttons>\n      \n        \n    </ion-toolbar>\n  </ion-header>\n\n  \n<ion-content class=\"hm_sign_bg\">\n    <ion-segment>\n        <ion-segment-button value=\"inactive\"  routerLink=\"/files\"  >\n          <ion-label>Files</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"active\" routerLink=\"/emergencyphonenumber\"  >\n          <ion-label >Emergency Phone<br> Numbers</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n\n\n    <div class=\"hm_project\">\n    <!--<div class=\"hm_project_tab\">\n      <ul>\n        <li [class.active]=\"tab=='active'\" (click)=\"tab_swap('active')\"> Ongoing</li>\n      <li [class.active]=\"tab=='inactive'\" (click)=\"tab_swap('inactive')\"> History</li>\n    </ul>\n      </div>-->\n      <div class=\"tabcontent\" [hidden]=\"tab=='inactive'\"  >\n       \n          <ion-card>\n              <ion-card-header>\n                 \n                <ion-row>\n                  <ion-col col=\"4\" center class=\"file-icon\">\n                    <ion-icon name=\"filing\" routerLink=\"/files\"></ion-icon>\n                    <h5 class=\"m-0 fs-16\">Folder</h5>\n                    </ion-col>\n                    <ion-col col=\"4\" class=\"file-icon\">\n                      <ion-icon name=\"filing\" routerLink=\"/files\"></ion-icon>\n                      <h5 class=\"m-0 fs-16 \" >New Folder Test</h5>\n                      </ion-col>\n                     <ion-col col=\"4\" class=\"file-icon\">\n                      <ion-icon name=\"filing\" routerLink=\"/files\"></ion-icon>\n                      <h5 class=\"m-0 fs-16\">Test Folder</h5>\n                    </ion-col>\n               </ion-row> \n               <ion-row>\n                <ion-col col=\"4\" center class=\"file-icon\">\n                  <ion-icon name=\"filing\" routerLink=\"/files\"></ion-icon>\n                  <h5 class=\"m-0 fs-16\">Folder</h5>\n                  </ion-col>\n                   \n                  \n             </ion-row> \n     </ion-card-header>\n            </ion-card>\n           \n          \n      </div>\n    \n    \n    </div>\n    </ion-content> \n    \n"

/***/ }),

/***/ "./src/app/files/files.page.scss":
/*!***************************************!*\
  !*** ./src/app/files/files.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.file-icon {\n  font-size: 50px;\n  text-align: center; }\n\n.m-0 {\n  margin: 0 !important; }\n\n.fs-16 {\n  font-size: 16px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmlsZXMvRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXGZpbGVzXFxmaWxlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFhLGVBQWU7RUFBRSxrQkFBa0IsRUFBQTs7QUFDaEQ7RUFBTSxvQkFBb0IsRUFBQTs7QUFDMUI7RUFBUSxlQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9maWxlcy9maWxlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyeyBiYWNrZ3JvdW5kOiAjMDMxNjM3ICFpbXBvcnRhbnQ7fVxyXG4uaG9tZS1pY29ueyAgICBjb2xvcjogI2ZmZjtiYWNrZ3JvdW5kOiBub25lO2ZvbnQtc2l6ZTogMjZweDt9XHJcbi5maWxlLWljb24geyBmb250LXNpemU6IDUwcHg7IHRleHQtYWxpZ246IGNlbnRlcjsgfVxyXG4ubS0weyBtYXJnaW46IDAgIWltcG9ydGFudDt9XHJcbi5mcy0xNnsgZm9udC1zaXplOiAxNnB4O30iXX0= */"

/***/ }),

/***/ "./src/app/files/files.page.ts":
/*!*************************************!*\
  !*** ./src/app/files/files.page.ts ***!
  \*************************************/
/*! exports provided: FilesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilesPage", function() { return FilesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var FilesPage = /** @class */ (function () {
    function FilesPage(navCtrl, modalCtrl, popoverCtrl) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.popoverCtrl = popoverCtrl;
    }
    FilesPage.prototype.segmentChanged = function (ev) {
        console.log('ionViewDidLoad FilesPage', ev);
        this.tab = "active";
    };
    FilesPage.prototype.tab_swap = function (type) {
        this.tab = type;
    };
    FilesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-files',
            template: __webpack_require__(/*! ./files.page.html */ "./src/app/files/files.page.html"),
            styles: [__webpack_require__(/*! ./files.page.scss */ "./src/app/files/files.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]])
    ], FilesPage);
    return FilesPage;
}());



/***/ })

}]);
//# sourceMappingURL=files-files-module.js.map