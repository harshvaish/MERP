(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["send-message-send-message-module"],{

/***/ "./src/app/send-message/send-message.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/send-message/send-message.module.ts ***!
  \*****************************************************/
/*! exports provided: SendMessagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SendMessagePageModule", function() { return SendMessagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _send_message_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./send-message.page */ "./src/app/send-message/send-message.page.ts");







var routes = [
    {
        path: '',
        component: _send_message_page__WEBPACK_IMPORTED_MODULE_6__["SendMessagePage"]
    }
];
var SendMessagePageModule = /** @class */ (function () {
    function SendMessagePageModule() {
    }
    SendMessagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_send_message_page__WEBPACK_IMPORTED_MODULE_6__["SendMessagePage"]]
        })
    ], SendMessagePageModule);
    return SendMessagePageModule;
}());



/***/ }),

/***/ "./src/app/send-message/send-message.page.html":
/*!*****************************************************!*\
  !*** ./src/app/send-message/send-message.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\"  routerLink=\"/message\" ><ion-icon name=\"menu\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title>\n       Message\n      </ion-title>\n      \n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" > <ion-icon name=\"refresh\"></ion-icon> </button>\n      </ion-buttons>\n        \n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n    <ion-card  class=\"msgsend-box\" >\n        <ion-card-content>\n              <ion-grid>\n                  <ion-row  class=\"text-center\"><h3  class=\"heading-title\">Send a Message</h3></ion-row>\n                  <ion-row>\n                     \n                      <ion-list  class=\"full-width\">\n                      \n                          <ion-item>\n                               <ion-input></ion-input>\n                            </ion-item>\n                        </ion-list>\n                        \n                    </ion-row>\n                    <ion-row  class=\"text-center\"><h3 class=\"heading-title\">Group / Building (Optional)</h3></ion-row>\n                    <ion-row class=\"text-center\">\n                       \n                        <ion-list class=\"full-width\">\n                             <ion-item >\n                              <ion-label>Kolkata</ion-label>\n                              <ion-select >\n                                  <ion-select-option>Emergency</ion-select-option>\n                                  <ion-select-option>Active Shooter</ion-select-option>\n                                  <ion-select-option>Intruder</ion-select-option>\n                                </ion-select>\n                            </ion-item> \n                          </ion-list>\n                      </ion-row>\n                      <ion-row  class=\"text-center\"><h3 class=\"heading-title\">Send to All / Incident Commanders</h3></ion-row>\n                      <ion-row class=\"text-center\">\n                         \n                          <ion-list class=\"full-width\">\n                               <ion-item >\n                                <ion-label>Incident Commanders</ion-label>\n                                <ion-select >\n                                    <ion-select-option>Incident Commanders</ion-select-option>\n                                    <ion-select-option>All</ion-select-option> \n                                  </ion-select>\n                              </ion-item> \n                            </ion-list>\n                        </ion-row>\n                          <ion-row  class=\"text-center\"><h3  class=\"heading-title\">Reply to All / Sender Only </h3></ion-row>\n                          <ion-row class=\"text-center\">\n                         \n                              <ion-list class=\"full-width\">\n                                   <ion-item >\n                                    <ion-label>Reply All</ion-label>\n                                    <ion-select >\n                                        <ion-select-option>Reply All</ion-select-option>\n                                        <ion-select-option>Sender Only</ion-select-option> \n                                      </ion-select>\n                                  </ion-item> \n                                </ion-list>\n                                <button class=\"btn-50\" ion-button margin-right routerLink=\"/emergency\">\n                                  Send Message\n                                 </button>\n                            </ion-row>\n                        </ion-grid>\n                           </ion-card-content>\n      </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/send-message/send-message.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/send-message/send-message.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.msgsend-box {\n  padding: 0px;\n  margin: 0;\n  background: #e6e6e6;\n  border-radius: 0;\n  text-align: center; }\n\n.heading-title {\n  font-size: 20px;\n  color: #000;\n  padding: 10px;\n  font-weight: bold; }\n\n.text-center h3 {\n  text-align: center;\n  width: 100%; }\n\n.full-width {\n  width: 100%;\n  border-radius: 5px; }\n\n.btn-50 {\n  width: 50%;\n  border-radius: 5px;\n  margin: 0 auto;\n  margin-top: 20px;\n  text-align: center;\n  padding: 10px;\n  border-top: 1px solid #989898;\n  background: #0d2a7a;\n  color: #fff;\n  height: 55px;\n  font-size: 18px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VuZC1tZXNzYWdlL0Q6XFxpb25pY19wcm9qZWN0XFxNRVJQXFxtZXJwL3NyY1xcYXBwXFxzZW5kLW1lc3NhZ2VcXHNlbmQtbWVzc2FnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFlLFlBQVk7RUFBSSxTQUFTO0VBQ3BDLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFBRSxrQkFBa0IsRUFBQTs7QUFFeEM7RUFBZ0IsZUFBZTtFQUFFLFdBQVc7RUFBRSxhQUFhO0VBQUUsaUJBQWlCLEVBQUE7O0FBQzlFO0VBQWlCLGtCQUFrQjtFQUFFLFdBQVcsRUFBQTs7QUFDaEQ7RUFBYSxXQUFXO0VBQUUsa0JBQWlCLEVBQUE7O0FBQzNDO0VBQVMsVUFBVTtFQUFFLGtCQUFpQjtFQUFDLGNBQWM7RUFBRSxnQkFBZ0I7RUFBRSxrQkFBa0I7RUFBRSxhQUFhO0VBQUssNkJBQTZCO0VBQUUsbUJBQW1CO0VBQUUsV0FBVztFQUFFLFlBQVk7RUFBQyxlQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9zZW5kLW1lc3NhZ2Uvc2VuZC1tZXNzYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7IGJhY2tncm91bmQ6ICMwMzE2MzcgIWltcG9ydGFudDt9XHJcbi5ob21lLWljb257ICAgIGNvbG9yOiAjZmZmO2JhY2tncm91bmQ6IG5vbmU7Zm9udC1zaXplOiAyNnB4O31cclxuLm1zZ3NlbmQtYm94IHsgcGFkZGluZzogMHB4OyAgIG1hcmdpbjogMDtcclxuICAgIGJhY2tncm91bmQ6ICNlNmU2ZTY7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwOyB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmhlYWRpbmctdGl0bGV7IGZvbnQtc2l6ZTogMjBweDsgY29sb3I6ICMwMDA7IHBhZGRpbmc6IDEwcHg7IGZvbnQtd2VpZ2h0OiBib2xkO31cclxuLnRleHQtY2VudGVyIGgzeyB0ZXh0LWFsaWduOiBjZW50ZXI7IHdpZHRoOiAxMDAlO31cclxuLmZ1bGwtd2lkdGh7IHdpZHRoOiAxMDAlOyBib3JkZXItcmFkaXVzOjVweDt9XHJcbi5idG4tNTB7IHdpZHRoOiA1MCU7IGJvcmRlci1yYWRpdXM6NXB4O21hcmdpbjogMCBhdXRvOyBtYXJnaW4tdG9wOiAyMHB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IHBhZGRpbmc6IDEwcHg7ICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjOTg5ODk4OyBiYWNrZ3JvdW5kOiAjMGQyYTdhOyBjb2xvcjogI2ZmZjsgaGVpZ2h0OiA1NXB4O2ZvbnQtc2l6ZTogMThweDt9XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/send-message/send-message.page.ts":
/*!***************************************************!*\
  !*** ./src/app/send-message/send-message.page.ts ***!
  \***************************************************/
/*! exports provided: SendMessagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SendMessagePage", function() { return SendMessagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SendMessagePage = /** @class */ (function () {
    function SendMessagePage() {
    }
    SendMessagePage.prototype.ngOnInit = function () {
    };
    SendMessagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-send-message',
            template: __webpack_require__(/*! ./send-message.page.html */ "./src/app/send-message/send-message.page.html"),
            styles: [__webpack_require__(/*! ./send-message.page.scss */ "./src/app/send-message/send-message.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SendMessagePage);
    return SendMessagePage;
}());



/***/ })

}]);
//# sourceMappingURL=send-message-send-message-module.js.map