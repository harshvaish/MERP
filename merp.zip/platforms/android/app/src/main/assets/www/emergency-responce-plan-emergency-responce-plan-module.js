(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["emergency-responce-plan-emergency-responce-plan-module"],{

/***/ "./src/app/emergency-responce-plan/emergency-responce-plan.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/emergency-responce-plan/emergency-responce-plan.module.ts ***!
  \***************************************************************************/
/*! exports provided: EmergencyResponcePlanPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmergencyResponcePlanPageModule", function() { return EmergencyResponcePlanPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _emergency_responce_plan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./emergency-responce-plan.page */ "./src/app/emergency-responce-plan/emergency-responce-plan.page.ts");







var routes = [
    {
        path: '',
        component: _emergency_responce_plan_page__WEBPACK_IMPORTED_MODULE_6__["EmergencyResponcePlanPage"]
    }
];
var EmergencyResponcePlanPageModule = /** @class */ (function () {
    function EmergencyResponcePlanPageModule() {
    }
    EmergencyResponcePlanPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_emergency_responce_plan_page__WEBPACK_IMPORTED_MODULE_6__["EmergencyResponcePlanPage"]]
        })
    ], EmergencyResponcePlanPageModule);
    return EmergencyResponcePlanPageModule;
}());



/***/ }),

/***/ "./src/app/emergency-responce-plan/emergency-responce-plan.page.html":
/*!***************************************************************************!*\
  !*** ./src/app/emergency-responce-plan/emergency-responce-plan.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"dark\" class=\"header\">\n     <ion-buttons slot=\"start\">\n      <button class=\"home-icon\" ><ion-icon name=\"home\"  routerLink=\"/home\"></ion-icon></button>\n  </ion-buttons>\n    <ion-title left>\n     Arodek\n    </ion-title>\n    <ion-buttons slot=\"end\">\n        <button class=\"home-icon\" routerLink=\"/icon-keys\" > <ion-icon name=\"help-circle\"></ion-icon> </button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\" ><ion-icon name=\"filing\"></ion-icon></button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\"  routerLink=\"/update-profile\"  ><ion-icon name=\"person\"></ion-icon></button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\" routerLink=\"/login\" ><ion-icon name=\"power\"></ion-icon></button>\n    </ion-buttons>\n    \n      \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-row  *ngFor=\"let emergency of emergencylist\">\n        <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n            <button class=\"btn {{emergency.bgcolor}}\" ion-button margin-right routerLink=\"/{{emergency.href}}\">\n             {{emergency.emergencyheadingtitle}} \n            </button>\n        </ion-col> \n      </ion-row>\n     \n                     \n                      <img src=\"assets/img/logo-merp.png\">   \n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/emergency-responce-plan/emergency-responce-plan.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/emergency-responce-plan/emergency-responce-plan.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.btn {\n  width: 100%;\n  padding: 10px;\n  box-shadow: 1px 1px 25px 0px #000000;\n  border-top: 1px solid #696969;\n  text-transform: uppercase;\n  color: #fff;\n  height: 55px;\n  font-size: 18px; }\n\n.dashboard-box {\n  padding: 0; }\n\n.nopadding {\n  padding: 0; }\n\n.yellow {\n  background: #f4c200; }\n\n.orange {\n  background: #da5601; }\n\n.mehroon {\n  background: #730e12; }\n\n.green {\n  background: #619109; }\n\n.darkgreen {\n  background: #1e3b0f; }\n\n.blue {\n  background: #0d2a78; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW1lcmdlbmN5LXJlc3BvbmNlLXBsYW4vRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXGVtZXJnZW5jeS1yZXNwb25jZS1wbGFuXFxlbWVyZ2VuY3ktcmVzcG9uY2UtcGxhbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFNLFdBQVc7RUFBRSxhQUFhO0VBQU0sb0NBQW9DO0VBQUksNkJBQTZCO0VBQUUseUJBQXlCO0VBQUksV0FBVztFQUFFLFlBQVk7RUFBQyxlQUFlLEVBQUE7O0FBQ25MO0VBQWdCLFVBQVUsRUFBQTs7QUFDMUI7RUFBWSxVQUFVLEVBQUE7O0FBQ3RCO0VBQVMsbUJBQWtCLEVBQUE7O0FBQzNCO0VBQVMsbUJBQWtCLEVBQUE7O0FBQzNCO0VBQVUsbUJBQWtCLEVBQUE7O0FBQzVCO0VBQVEsbUJBQWtCLEVBQUE7O0FBQzFCO0VBQVksbUJBQWtCLEVBQUE7O0FBQzlCO0VBQU8sbUJBQWtCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9lbWVyZ2VuY3ktcmVzcG9uY2UtcGxhbi9lbWVyZ2VuY3ktcmVzcG9uY2UtcGxhbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyeyBiYWNrZ3JvdW5kOiAjMDMxNjM3ICFpbXBvcnRhbnQ7fVxyXG4uaG9tZS1pY29ueyAgICBjb2xvcjogI2ZmZjtiYWNrZ3JvdW5kOiBub25lO2ZvbnQtc2l6ZTogMjZweDt9XHJcbi5idG57IHdpZHRoOiAxMDAlOyBwYWRkaW5nOiAxMHB4OyAgICAgYm94LXNoYWRvdzogMXB4IDFweCAyNXB4IDBweCAjMDAwMDAwOyAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjNjk2OTY5OyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyAgIGNvbG9yOiAjZmZmOyBoZWlnaHQ6IDU1cHg7Zm9udC1zaXplOiAxOHB4O31cclxuLmRhc2hib2FyZC1ib3h7IHBhZGRpbmc6IDA7fVxyXG4ubm9wYWRkaW5neyBwYWRkaW5nOiAwO31cclxuLnllbGxvd3sgYmFja2dyb3VuZDojZjRjMjAwO31cclxuLm9yYW5nZXsgYmFja2dyb3VuZDojZGE1NjAxO31cclxuLm1laHJvb257IGJhY2tncm91bmQ6IzczMGUxMjt9XHJcbi5ncmVlbnsgYmFja2dyb3VuZDojNjE5MTA5O31cclxuLmRhcmtncmVlbnsgYmFja2dyb3VuZDojMWUzYjBmO31cclxuLmJsdWV7IGJhY2tncm91bmQ6IzBkMmE3ODt9XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/emergency-responce-plan/emergency-responce-plan.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/emergency-responce-plan/emergency-responce-plan.page.ts ***!
  \*************************************************************************/
/*! exports provided: EmergencyResponcePlanPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmergencyResponcePlanPage", function() { return EmergencyResponcePlanPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var EmergencyResponcePlanPage = /** @class */ (function () {
    function EmergencyResponcePlanPage() {
        this.emergencylist = [
            { bgcolor: 'yellow', emergencyheadingtitle: 'Incident Management System', href: 'emergency-responce-plan' },
            { bgcolor: 'yellow', emergencyheadingtitle: 'Evacuation' },
            { bgcolor: 'yellow', emergencyheadingtitle: 'Reverse Evacuation' },
            { bgcolor: 'yellow', emergencyheadingtitle: 'Lock Down / Secured Perimeter' },
            { bgcolor: 'yellow', emergencyheadingtitle: 'Selter in Place' },
            { bgcolor: 'yellow', emergencyheadingtitle: 'Reunification' },
            { bgcolor: 'orange', emergencyheadingtitle: 'Fire' },
            { bgcolor: 'orange', emergencyheadingtitle: 'Hazardous Materials' },
            { bgcolor: 'orange', emergencyheadingtitle: 'Medical Emergency' },
            { bgcolor: 'orange', emergencyheadingtitle: 'Winter Storm' },
            { bgcolor: 'orange', emergencyheadingtitle: 'Earthquake' },
            { bgcolor: 'mehroon', emergencyheadingtitle: 'Violence on School Grounds' },
            { bgcolor: 'mehroon', emergencyheadingtitle: 'Sexual Assault' },
            { bgcolor: 'mehroon', emergencyheadingtitle: 'Suicide Attempt / Threat ' },
            { bgcolor: 'mehroon', emergencyheadingtitle: 'Missing Person' },
            { bgcolor: 'mehroon', emergencyheadingtitle: 'Bomb Threat' },
            { bgcolor: 'mehroon', emergencyheadingtitle: 'Civil Disorder' },
            { bgcolor: 'green', emergencyheadingtitle: 'Power Outage' },
            { bgcolor: 'green', emergencyheadingtitle: 'Natural Gas leak / Loss of Service' },
            { bgcolor: 'green', emergencyheadingtitle: 'Flooding / Sewer Incident' },
            { bgcolor: 'green', emergencyheadingtitle: 'Communication Loss' },
            { bgcolor: 'green', emergencyheadingtitle: 'Food and Water Contamination' },
            { bgcolor: 'green', emergencyheadingtitle: 'Pandemic' },
            { bgcolor: 'darkgreen', emergencyheadingtitle: 'Transpotation Incident' },
            { bgcolor: 'darkgreen', emergencyheadingtitle: 'Special Rescue' },
            { bgcolor: 'darkgreen', emergencyheadingtitle: 'Structure Collapse' },
            { bgcolor: 'darkgreen', emergencyheadingtitle: 'Death of Student / Staff Member' },
            { bgcolor: 'darkgreen', emergencyheadingtitle: 'Chemical Attack / Incident' },
            { bgcolor: 'darkgreen', emergencyheadingtitle: 'Biological Attack / Incident' },
            { bgcolor: 'blue', emergencyheadingtitle: 'Radiological Attack / Release' },
            { bgcolor: 'blue', emergencyheadingtitle: 'Nuclear Attack / Release' },
            { bgcolor: 'blue', emergencyheadingtitle: 'Explosion' }
        ];
    }
    EmergencyResponcePlanPage.prototype.ngOnInit = function () {
    };
    EmergencyResponcePlanPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-emergency-responce-plan',
            template: __webpack_require__(/*! ./emergency-responce-plan.page.html */ "./src/app/emergency-responce-plan/emergency-responce-plan.page.html"),
            styles: [__webpack_require__(/*! ./emergency-responce-plan.page.scss */ "./src/app/emergency-responce-plan/emergency-responce-plan.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], EmergencyResponcePlanPage);
    return EmergencyResponcePlanPage;
}());



/***/ })

}]);
//# sourceMappingURL=emergency-responce-plan-emergency-responce-plan-module.js.map