(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forgetpassword-forgetpassword-module"],{

/***/ "./src/app/forgetpassword/forgetpassword.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/forgetpassword/forgetpassword.module.ts ***!
  \*********************************************************/
/*! exports provided: ForgetpasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetpasswordPageModule", function() { return ForgetpasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _forgetpassword_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./forgetpassword.page */ "./src/app/forgetpassword/forgetpassword.page.ts");







var routes = [
    {
        path: '',
        component: _forgetpassword_page__WEBPACK_IMPORTED_MODULE_6__["ForgetpasswordPage"]
    }
];
var ForgetpasswordPageModule = /** @class */ (function () {
    function ForgetpasswordPageModule() {
    }
    ForgetpasswordPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_forgetpassword_page__WEBPACK_IMPORTED_MODULE_6__["ForgetpasswordPage"]]
        })
    ], ForgetpasswordPageModule);
    return ForgetpasswordPageModule;
}());



/***/ }),

/***/ "./src/app/forgetpassword/forgetpassword.page.html":
/*!*********************************************************!*\
  !*** ./src/app/forgetpassword/forgetpassword.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-content>\n    <ion-card  class=\"login-box\">\n        <ion-card-header class=\"login-heading\">\n           <ion-card-title  class=\"heading\" >Forget Password</ion-card-title>\n        </ion-card-header>\n      \n        <ion-card-content >\n            \n            <ion-item class=\"form-control\">\n              <ion-label stacked>New Password</ion-label>\n              <ion-input placeholder=\"password\" ></ion-input>\n            </ion-item>\n          \n            <ion-item class=\"form-control\">\n              <ion-label stacked>Confirm Password</ion-label>\n              <ion-input type=\"password\"placeholder=\"password\"  ></ion-input>\n            </ion-item>\n          \n            <div text-center margin-top>\n              <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n               Password Reset\n              </button>\n              <p  routerLink=\"/login\" class=\"forget\">Go To Login</p>\n           \n            </div>\n        </ion-card-content>\n      </ion-card>\n\n     \n \n</ion-content>\n<ion-footer>\n    <img src=\"assets/img/logo-merp.png\">\n\n\n    \n  </ion-footer>"

/***/ }),

/***/ "./src/app/forgetpassword/forgetpassword.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/forgetpassword/forgetpassword.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".login-heading {\n  background: #031637;\n  padding: 15px;\n  text-align: center;\n  line-height: 2; }\n\n.heading {\n  color: #fff;\n  font-size: 26px; }\n\n.form-control {\n  background: #fff;\n  margin-top: 15px; }\n\n.login-box {\n  background: #dde5fa;\n  margin-top: 25%; }\n\n.btn {\n  width: 100%;\n  padding: 10px;\n  background: #0d2a7a;\n  color: #fff;\n  height: 50px; }\n\n.forget {\n  -webkit-text-decoration-line: underline;\n          text-decoration-line: underline;\n  margin-top: 10px; }\n\n.footer-md:before {\n  background: none; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9yZ2V0cGFzc3dvcmQvRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXGZvcmdldHBhc3N3b3JkXFxmb3JnZXRwYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFBZ0IsbUJBQW1CO0VBQUUsYUFBYTtFQUFFLGtCQUFrQjtFQUFFLGNBQWMsRUFBQTs7QUFDdEY7RUFBVSxXQUFVO0VBQUUsZUFBZSxFQUFBOztBQUNyQztFQUFlLGdCQUFnQjtFQUFFLGdCQUFnQixFQUFBOztBQUNqRDtFQUFZLG1CQUFtQjtFQUFFLGVBQWUsRUFBQTs7QUFDaEQ7RUFBTSxXQUFXO0VBQUUsYUFBYTtFQUFFLG1CQUFtQjtFQUFFLFdBQVc7RUFBRSxZQUFZLEVBQUE7O0FBQ2hGO0VBQVMsdUNBQStCO1VBQS9CLCtCQUErQjtFQUFFLGdCQUFnQixFQUFBOztBQUMxRDtFQUFtQixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2ZvcmdldHBhc3N3b3JkL2ZvcmdldHBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ubG9naW4taGVhZGluZ3sgYmFja2dyb3VuZDogIzAzMTYzNzsgcGFkZGluZzogMTVweDsgdGV4dC1hbGlnbjogY2VudGVyOyBsaW5lLWhlaWdodDogMjt9XHJcbi5oZWFkaW5neyBjb2xvcjojZmZmOyBmb250LXNpemU6IDI2cHg7fVxyXG4uZm9ybS1jb250cm9seyBiYWNrZ3JvdW5kOiAjZmZmOyBtYXJnaW4tdG9wOiAxNXB4OyAgfVxyXG4ubG9naW4tYm94eyBiYWNrZ3JvdW5kOiAjZGRlNWZhOyBtYXJnaW4tdG9wOiAyNSU7fVxyXG4uYnRueyB3aWR0aDogMTAwJTsgcGFkZGluZzogMTBweDsgYmFja2dyb3VuZDogIzBkMmE3YTsgY29sb3I6ICNmZmY7IGhlaWdodDogNTBweDt9XHJcbi5mb3JnZXR7IHRleHQtZGVjb3JhdGlvbi1saW5lOiB1bmRlcmxpbmU7IG1hcmdpbi10b3A6IDEwcHg7fVxyXG4uZm9vdGVyLW1kOmJlZm9yZXsgYmFja2dyb3VuZDogbm9uZTt9Il19 */"

/***/ }),

/***/ "./src/app/forgetpassword/forgetpassword.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/forgetpassword/forgetpassword.page.ts ***!
  \*******************************************************/
/*! exports provided: ForgetpasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetpasswordPage", function() { return ForgetpasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ForgetpasswordPage = /** @class */ (function () {
    function ForgetpasswordPage() {
    }
    ForgetpasswordPage.prototype.ngOnInit = function () {
    };
    ForgetpasswordPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-forgetpassword',
            template: __webpack_require__(/*! ./forgetpassword.page.html */ "./src/app/forgetpassword/forgetpassword.page.html"),
            styles: [__webpack_require__(/*! ./forgetpassword.page.scss */ "./src/app/forgetpassword/forgetpassword.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ForgetpasswordPage);
    return ForgetpasswordPage;
}());



/***/ })

}]);
//# sourceMappingURL=forgetpassword-forgetpassword-module.js.map