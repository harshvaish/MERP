(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.html":
/*!***************************************!*\
  !*** ./src/app/login/login.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-content>\n    <ion-card  class=\"login-box\">\n        <ion-card-header class=\"login-heading\">\n           <ion-card-title  class=\"heading\" >Mobile Emergency Responce Plan</ion-card-title>\n        </ion-card-header>\n      \n        <ion-card-content >\n            \n            <ion-item class=\"form-control\">\n              <ion-label stacked>Email Address</ion-label>\n              <ion-input placeholder=\"username\" ></ion-input>\n            </ion-item>\n          \n            <ion-item class=\"form-control\">\n              <ion-label stacked>Password</ion-label>\n              <ion-input type=\"password\"placeholder=\"password\"  ></ion-input>\n            </ion-item>\n          \n            <div text-center margin-top>\n              <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                SIGN IN\n              </button>\n              <p  routerLink=\"/forgetpassword\" class=\"forget\">Forget your Password</p>\n           \n            </div>\n        </ion-card-content>\n      </ion-card>\n\n     \n \n</ion-content>\n<ion-footer>\n    <img src=\"assets/img/logo-merp.png\">\n\n\n    \n  </ion-footer>"

/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".login-heading {\n  background: #031637;\n  padding: 15px;\n  text-align: center;\n  line-height: 2; }\n\n.heading {\n  color: #fff;\n  font-size: 26px; }\n\n.form-control {\n  background: #fff;\n  margin-top: 15px; }\n\n.login-box {\n  background: #dde5fa;\n  margin-top: 25%; }\n\n.btn {\n  width: 100%;\n  padding: 10px;\n  background: #0d2a7a;\n  color: #fff;\n  height: 50px; }\n\n.forget {\n  -webkit-text-decoration-line: underline;\n          text-decoration-line: underline;\n  margin-top: 10px; }\n\n.footer-md:before {\n  background: none; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXGxvZ2luXFxsb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFBZ0IsbUJBQW1CO0VBQUUsYUFBYTtFQUFFLGtCQUFrQjtFQUFFLGNBQWMsRUFBQTs7QUFDdEY7RUFBVSxXQUFVO0VBQUUsZUFBZSxFQUFBOztBQUNyQztFQUFlLGdCQUFnQjtFQUFFLGdCQUFnQixFQUFBOztBQUNqRDtFQUFZLG1CQUFtQjtFQUFFLGVBQWUsRUFBQTs7QUFDaEQ7RUFBTSxXQUFXO0VBQUUsYUFBYTtFQUFFLG1CQUFtQjtFQUFFLFdBQVc7RUFBRSxZQUFZLEVBQUE7O0FBQ2hGO0VBQVMsdUNBQStCO1VBQS9CLCtCQUErQjtFQUFFLGdCQUFnQixFQUFBOztBQUMxRDtFQUFtQixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ubG9naW4taGVhZGluZ3sgYmFja2dyb3VuZDogIzAzMTYzNzsgcGFkZGluZzogMTVweDsgdGV4dC1hbGlnbjogY2VudGVyOyBsaW5lLWhlaWdodDogMjt9XHJcbi5oZWFkaW5neyBjb2xvcjojZmZmOyBmb250LXNpemU6IDI2cHg7fVxyXG4uZm9ybS1jb250cm9seyBiYWNrZ3JvdW5kOiAjZmZmOyBtYXJnaW4tdG9wOiAxNXB4OyAgfVxyXG4ubG9naW4tYm94eyBiYWNrZ3JvdW5kOiAjZGRlNWZhOyBtYXJnaW4tdG9wOiAyNSU7fVxyXG4uYnRueyB3aWR0aDogMTAwJTsgcGFkZGluZzogMTBweDsgYmFja2dyb3VuZDogIzBkMmE3YTsgY29sb3I6ICNmZmY7IGhlaWdodDogNTBweDt9XHJcbi5mb3JnZXR7IHRleHQtZGVjb3JhdGlvbi1saW5lOiB1bmRlcmxpbmU7IG1hcmdpbi10b3A6IDEwcHg7fVxyXG4uZm9vdGVyLW1kOmJlZm9yZXsgYmFja2dyb3VuZDogbm9uZTt9Il19 */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var LoginPage = /** @class */ (function () {
    function LoginPage() {
    }
    LoginPage.prototype.ngOnInit = function () {
    };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map