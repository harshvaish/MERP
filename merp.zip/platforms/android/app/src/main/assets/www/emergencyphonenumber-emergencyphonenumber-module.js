(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["emergencyphonenumber-emergencyphonenumber-module"],{

/***/ "./src/app/emergencyphonenumber/emergencyphonenumber.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/emergencyphonenumber/emergencyphonenumber.module.ts ***!
  \*********************************************************************/
/*! exports provided: EmergencyphonenumberPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmergencyphonenumberPageModule", function() { return EmergencyphonenumberPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _emergencyphonenumber_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./emergencyphonenumber.page */ "./src/app/emergencyphonenumber/emergencyphonenumber.page.ts");







var routes = [
    {
        path: '',
        component: _emergencyphonenumber_page__WEBPACK_IMPORTED_MODULE_6__["EmergencyphonenumberPage"]
    }
];
var EmergencyphonenumberPageModule = /** @class */ (function () {
    function EmergencyphonenumberPageModule() {
    }
    EmergencyphonenumberPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_emergencyphonenumber_page__WEBPACK_IMPORTED_MODULE_6__["EmergencyphonenumberPage"]]
        })
    ], EmergencyphonenumberPageModule);
    return EmergencyphonenumberPageModule;
}());



/***/ }),

/***/ "./src/app/emergencyphonenumber/emergencyphonenumber.page.html":
/*!*********************************************************************!*\
  !*** ./src/app/emergencyphonenumber/emergencyphonenumber.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"dark\" class=\"header\">\n     <ion-buttons slot=\"start\">\n      <button class=\"home-icon\"  routerLink=\"/home\"  ><ion-icon name=\"home\"></ion-icon></button>\n  </ion-buttons>\n    <ion-title left>\n     Arodek\n    </ion-title>\n    <ion-buttons slot=\"end\">\n        <button class=\"home-icon\" routerLink=\"/icon-keys\" > <ion-icon name=\"help-circle\"></ion-icon> </button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\" ><ion-icon name=\"filing\" routerLink=\"/files\"></ion-icon></button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\"  routerLink=\"/update-profile\"  ><ion-icon name=\"person\"></ion-icon></button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\" routerLink=\"/login\"  ><ion-icon name=\"power\"></ion-icon></button>\n    </ion-buttons>\n    \n      \n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content class=\"hm_sign_bg\">\n  <ion-segment>\n      <ion-segment-button value=\"inactive\"  routerLink=\"/files\"  >\n        <ion-label>Files</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"active\" routerLink=\"/emergencyphonenumber\"  >\n        <ion-label >Emergency Phone<br> Numbers</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n\n\n  <div class=\"hm_project\">\n  <!--<div class=\"hm_project_tab\">\n    <ul>\n      <li [class.active]=\"tab=='active'\" (click)=\"tab_swap('active')\"> Ongoing</li>\n    <li [class.active]=\"tab=='inactive'\" (click)=\"tab_swap('inactive')\"> History</li>\n  </ul>\n    </div>-->\n    <div class=\"tabcontent\" >\n      <ion-card  class=\"login-box\">\n        <ion-card-header class=\"login-heading\">\n           <ion-card-title  class=\"heading\" >MERP EMERGENCY PHONE NUMBERS CONTACT LIST</ion-card-title>\n        </ion-card-header>\n       \n       <ion-card-content >\n             <ion-item  >\n             <h4>FOR ALL EMERGENCIES CALL 911</h4>\n              </ion-item>       \n       </ion-card-content>\n     \n       <ion-card-header class=\"table-heading\">\n          <ion-card-title > \n            <ion-row>\n              <ion-col size=\"7\">\n                  <h5 class=\"msg-locate m-0\">Contact</h5>\n                   </ion-col>\n              <ion-col  size=\"5\" class=\"text-right\">\n                <h5 class=\"m-0\">Number</h5>\n                  </ion-col>\n             \n            </ion-row>\n          </ion-card-title>\n       </ion-card-header>\n      \n      <ion-card-content class=\"m-0 p-0 table\" >\n          <ion-row>\n              <ion-col size=\"7\">\n                  <h5 class=\"msg-locate m-0\">Police/Fire/EMS</h5>\n                   </ion-col>\n              <ion-col  size=\"5\" class=\"text-right\">\n                <h5 class=\"m-0\">911</h5>\n                  </ion-col>  \n            </ion-row>\n           \n             \n      </ion-card-content>\n    \n     \n     \n      </ion-card>\n\n     \n         \n        \n    </div>\n  \n  \n  </div>\n  </ion-content> \n  \n"

/***/ }),

/***/ "./src/app/emergencyphonenumber/emergencyphonenumber.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/emergencyphonenumber/emergencyphonenumber.page.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.file-icon {\n  font-size: 50px;\n  text-align: center; }\n\n.m-0 {\n  margin: 0 !important; }\n\n.p-0 {\n  padding: 10px !important; }\n\n.fs-16 {\n  font-size: 16px; }\n\n.login-heading {\n  background: #031637;\n  padding: 15px;\n  text-align: center;\n  line-height: 2; }\n\n.heading {\n  color: #fff;\n  font-size: 16px; }\n\n.form-control {\n  background: #fff;\n  margin-top: 15px; }\n\n.login-box {\n  background: #ffffff;\n  margin-top: 2%; }\n\n.table-heading {\n  background: #ccc;\n  padding: 5px;\n  text-align: left; }\n\ntable {\n  border: 1px solid #ccc; }\n\n.header .col {\n  background-color: lightgrey; }\n\n.col {\n  border: solid 1px grey;\n  border-bottom-style: none;\n  border-right-style: none; }\n\n.col:last-child {\n  border-right: solid 1px grey; }\n\n.row:last-child .col {\n  border-bottom: solid 1px grey; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW1lcmdlbmN5cGhvbmVudW1iZXIvRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXGVtZXJnZW5jeXBob25lbnVtYmVyXFxlbWVyZ2VuY3lwaG9uZW51bWJlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFhLGVBQWU7RUFBRSxrQkFBa0IsRUFBQTs7QUFDaEQ7RUFBTSxvQkFBb0IsRUFBQTs7QUFDMUI7RUFBTSx3QkFBd0IsRUFBQTs7QUFDOUI7RUFBUSxlQUFlLEVBQUE7O0FBRXZCO0VBQWdCLG1CQUFtQjtFQUFFLGFBQWE7RUFBRSxrQkFBa0I7RUFBRSxjQUFjLEVBQUE7O0FBQ3RGO0VBQVUsV0FBVTtFQUFFLGVBQWUsRUFBQTs7QUFDckM7RUFBZSxnQkFBZ0I7RUFBRSxnQkFBZ0IsRUFBQTs7QUFDakQ7RUFBWSxtQkFBbUI7RUFBRSxjQUFjLEVBQUE7O0FBQy9DO0VBQWdCLGdCQUFnQjtFQUFFLFlBQVk7RUFBRSxnQkFBZ0IsRUFBQTs7QUFDaEU7RUFBTyxzQkFBc0IsRUFBQTs7QUFDN0I7RUFDSSwyQkFBMEIsRUFBQTs7QUFHOUI7RUFDSSxzQkFBc0I7RUFDdEIseUJBQXlCO0VBQ3pCLHdCQUF3QixFQUFBOztBQUc1QjtFQUNJLDRCQUE0QixFQUFBOztBQUdoQztFQUNJLDZCQUE2QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvZW1lcmdlbmN5cGhvbmVudW1iZXIvZW1lcmdlbmN5cGhvbmVudW1iZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcnsgYmFja2dyb3VuZDogIzAzMTYzNyAhaW1wb3J0YW50O31cclxuLmhvbWUtaWNvbnsgICAgY29sb3I6ICNmZmY7YmFja2dyb3VuZDogbm9uZTtmb250LXNpemU6IDI2cHg7fVxyXG4uZmlsZS1pY29uIHsgZm9udC1zaXplOiA1MHB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IH1cclxuLm0tMHsgbWFyZ2luOiAwICFpbXBvcnRhbnQ7fVxyXG4ucC0weyBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7fVxyXG4uZnMtMTZ7IGZvbnQtc2l6ZTogMTZweDt9XHJcblxyXG4ubG9naW4taGVhZGluZ3sgYmFja2dyb3VuZDogIzAzMTYzNzsgcGFkZGluZzogMTVweDsgdGV4dC1hbGlnbjogY2VudGVyOyBsaW5lLWhlaWdodDogMjt9XHJcbi5oZWFkaW5neyBjb2xvcjojZmZmOyBmb250LXNpemU6IDE2cHg7fVxyXG4uZm9ybS1jb250cm9seyBiYWNrZ3JvdW5kOiAjZmZmOyBtYXJnaW4tdG9wOiAxNXB4OyAgfVxyXG4ubG9naW4tYm94eyBiYWNrZ3JvdW5kOiAjZmZmZmZmOyBtYXJnaW4tdG9wOiAyJTt9XHJcbi50YWJsZS1oZWFkaW5neyBiYWNrZ3JvdW5kOiAjY2NjOyBwYWRkaW5nOiA1cHg7IHRleHQtYWxpZ246IGxlZnQ7IH1cclxudGFibGV7IGJvcmRlcjogMXB4IHNvbGlkICNjY2M7IH1cclxuLmhlYWRlciAuY29sIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6bGlnaHRncmV5O1xyXG59XHJcblxyXG4uY29sIHtcclxuICAgIGJvcmRlcjogc29saWQgMXB4IGdyZXk7XHJcbiAgICBib3JkZXItYm90dG9tLXN0eWxlOiBub25lO1xyXG4gICAgYm9yZGVyLXJpZ2h0LXN0eWxlOiBub25lO1xyXG59XHJcblxyXG4uY29sOmxhc3QtY2hpbGQge1xyXG4gICAgYm9yZGVyLXJpZ2h0OiBzb2xpZCAxcHggZ3JleTtcclxufVxyXG5cclxuLnJvdzpsYXN0LWNoaWxkIC5jb2wge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4IGdyZXk7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/emergencyphonenumber/emergencyphonenumber.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/emergencyphonenumber/emergencyphonenumber.page.ts ***!
  \*******************************************************************/
/*! exports provided: EmergencyphonenumberPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmergencyphonenumberPage", function() { return EmergencyphonenumberPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var EmergencyphonenumberPage = /** @class */ (function () {
    function EmergencyphonenumberPage() {
    }
    EmergencyphonenumberPage.prototype.ngOnInit = function () {
    };
    EmergencyphonenumberPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-emergencyphonenumber',
            template: __webpack_require__(/*! ./emergencyphonenumber.page.html */ "./src/app/emergencyphonenumber/emergencyphonenumber.page.html"),
            styles: [__webpack_require__(/*! ./emergencyphonenumber.page.scss */ "./src/app/emergencyphonenumber/emergencyphonenumber.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], EmergencyphonenumberPage);
    return EmergencyphonenumberPage;
}());



/***/ })

}]);
//# sourceMappingURL=emergencyphonenumber-emergencyphonenumber-module.js.map