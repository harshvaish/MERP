(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["message-message-module"],{

/***/ "./src/app/message/message.module.ts":
/*!*******************************************!*\
  !*** ./src/app/message/message.module.ts ***!
  \*******************************************/
/*! exports provided: MessagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePageModule", function() { return MessagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _message_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./message.page */ "./src/app/message/message.page.ts");







var routes = [
    {
        path: '',
        component: _message_page__WEBPACK_IMPORTED_MODULE_6__["MessagePage"]
    }
];
var MessagePageModule = /** @class */ (function () {
    function MessagePageModule() {
    }
    MessagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_message_page__WEBPACK_IMPORTED_MODULE_6__["MessagePage"]]
        })
    ], MessagePageModule);
    return MessagePageModule;
}());



/***/ }),

/***/ "./src/app/message/message.page.html":
/*!*******************************************!*\
  !*** ./src/app/message/message.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\"  routerLink=\"/home\" ><ion-icon name=\"home\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title class=\"title-left\">\n       Message\n      </ion-title>\n      \n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" > <h5>Edit</h5> </button>\n      </ion-buttons>\n        \n    <ion-buttons slot=\"end\">\n        <button  class=\"home-icon\" (click)=\"presentModal()\" > <ion-icon name=\"refresh\"></ion-icon> </button>\n    </ion-buttons>\n      \n  </ion-toolbar>\n  </ion-header>\n  \n\n<ion-content>\n    <ion-card  class=\"message-box\" *ngFor=\"let message of messages\">\n        <ion-card-content no-padding>\n              <ion-grid>\n                  <ion-row>\n                      <ion-col size=\"7\">\n                        <h3 class=\"msg-heading\">{{message.name}}</h3>\n                        <h5 class=\"msg-locate\">{{message.locate}}</h5>\n                        <p class=\"msg-category\">{{message.category}}</p>\n                      </ion-col>\n                      <ion-col  size=\"3\" class=\"text-right\">\n                        <h5>{{message.date}}</h5>\n                        <p>{{message.time}}</p>\n                      </ion-col>\n                      <ion-col  size=\"2\">\n                          <ion-icon name=\"close\" class=\"msg-dlt\"></ion-icon> \n                      </ion-col> \n                    </ion-row>\n                        </ion-grid>\n                           </ion-card-content>\n      </ion-card>\n\n\n\n      <!--<ion-card  class=\"message-box\">\n          <ion-card-content no-padding>\n                <ion-grid>\n                    <ion-row>\n                        <ion-col size=\"7\">\n                          <h3 class=\"msg-heading\">Sumeet Zade</h3>\n                          <h5 class=\"msg-locate\">Kolkata</h5>\n                          <p class=\"msg-category\">Emergency</p>\n                        </ion-col>\n                        <ion-col  size=\"3\" class=\"text-right\">\n                          <h5>4/16/2019</h5>\n                          <p>3:30pm</p>\n                        </ion-col>\n                        <ion-col  size=\"2\">\n                            <ion-icon name=\"close\" class=\"msg-dlt\"></ion-icon> \n                        </ion-col> \n                      </ion-row>\n                          </ion-grid>\n                             </ion-card-content>\n        </ion-card>-->\n    \n</ion-content>\n"

/***/ }),

/***/ "./src/app/message/message.page.scss":
/*!*******************************************!*\
  !*** ./src/app/message/message.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.title-left {\n  text-align: left;\n  padding: 0px 45px; }\n\n.message-box {\n  padding: 0px;\n  margin: 0;\n  background: #4c4c4c;\n  border-radius: 0;\n  text-align: center;\n  color: #ffffff;\n  border-bottom: 1px solid #333; }\n\n.msg-heading {\n  color: #ffffff;\n  font-size: 20px;\n  text-align: left; }\n\n.msg-locate {\n  color: #ffffff;\n  font-size: 16px;\n  text-align: left;\n  margin-bottom: 10px; }\n\n.msg-category {\n  color: #efefef;\n  font-size: 15px;\n  text-align: left; }\n\n.text-right {\n  text-align: right; }\n\n.msg-dlt {\n  font-size: 48px;\n  color: #ff0000;\n  text-align: right;\n  font-weight: bold; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVzc2FnZS9EOlxcaW9uaWNfcHJvamVjdFxcTUVSUFxcbWVycC9zcmNcXGFwcFxcbWVzc2FnZVxcbWVzc2FnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFnQixnQkFBZ0I7RUFBSyxpQkFBaUIsRUFBQTs7QUFDdEQ7RUFBZSxZQUFZO0VBQUksU0FBUztFQUFJLG1CQUFtQjtFQUMzRCxnQkFBZ0I7RUFBRSxrQkFBa0I7RUFBRSxjQUFjO0VBQUUsNkJBQTZCLEVBQUE7O0FBRXZGO0VBQWMsY0FBYztFQUFFLGVBQWU7RUFBRSxnQkFBZ0IsRUFBQTs7QUFDL0Q7RUFBYSxjQUFjO0VBQUUsZUFBZTtFQUFFLGdCQUFnQjtFQUFFLG1CQUFtQixFQUFBOztBQUNuRjtFQUFlLGNBQWM7RUFBRSxlQUFlO0VBQUUsZ0JBQWdCLEVBQUE7O0FBQy9EO0VBQWEsaUJBQWlCLEVBQUE7O0FBQzlCO0VBQVUsZUFBZTtFQUFFLGNBQWM7RUFBRSxpQkFBaUI7RUFBRSxpQkFBaUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL21lc3NhZ2UvbWVzc2FnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyeyBiYWNrZ3JvdW5kOiAjMDMxNjM3ICFpbXBvcnRhbnQ7fVxyXG4uaG9tZS1pY29ueyAgICBjb2xvcjogI2ZmZjtiYWNrZ3JvdW5kOiBub25lO2ZvbnQtc2l6ZTogMjZweDt9XHJcbi50aXRsZS1sZWZ0eyAgICB0ZXh0LWFsaWduOiBsZWZ0OyAgICBwYWRkaW5nOiAwcHggNDVweDt9XHJcbi5tZXNzYWdlLWJveCB7IHBhZGRpbmc6IDBweDsgICBtYXJnaW46IDA7ICAgYmFja2dyb3VuZDogIzRjNGM0YztcclxuICAgIGJvcmRlci1yYWRpdXM6IDA7IHRleHQtYWxpZ246IGNlbnRlcjsgY29sb3I6ICNmZmZmZmY7IGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMzMzO1xyXG59XHJcbi5tc2ctaGVhZGluZ3sgY29sb3I6ICNmZmZmZmY7IGZvbnQtc2l6ZTogMjBweDsgdGV4dC1hbGlnbjogbGVmdDt9XHJcbi5tc2ctbG9jYXRleyBjb2xvcjogI2ZmZmZmZjsgZm9udC1zaXplOiAxNnB4OyB0ZXh0LWFsaWduOiBsZWZ0OyBtYXJnaW4tYm90dG9tOiAxMHB4O31cclxuLm1zZy1jYXRlZ29yeXsgY29sb3I6ICNlZmVmZWY7IGZvbnQtc2l6ZTogMTVweDsgdGV4dC1hbGlnbjogbGVmdDt9XHJcbiAudGV4dC1yaWdodHsgdGV4dC1hbGlnbjogcmlnaHQ7fVxyXG4gLm1zZy1kbHR7IGZvbnQtc2l6ZTogNDhweDsgY29sb3I6ICNmZjAwMDA7IHRleHQtYWxpZ246IHJpZ2h0OyBmb250LXdlaWdodDogYm9sZDt9Il19 */"

/***/ }),

/***/ "./src/app/message/message.page.ts":
/*!*****************************************!*\
  !*** ./src/app/message/message.page.ts ***!
  \*****************************************/
/*! exports provided: MessagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePage", function() { return MessagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _deepakdummy_deepakdummy_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../deepakdummy/deepakdummy.component */ "./src/app/deepakdummy/deepakdummy.component.ts");




var MessagePage = /** @class */ (function () {
    function MessagePage(modalController) {
        this.modalController = modalController;
        this.messages = [
            { name: 'Sumit Zade', locate: 'Kolkata', category: 'Emergency', date: '04/12/2019', time: '3:30pm' },
            { name: 'Deepak Gupta', locate: 'Delhi', category: 'Emergency', date: '21/12/2019', time: '3:30pm' },
            { name: 'Sumit Zade', locate: 'Kolkata', category: 'Emergency', date: '04/12/2019', time: '3:30pm' },
            { name: 'Deepak Gupta', locate: 'Delhi', category: 'Emergency', date: '21/12/2019', time: '3:30pm' },
            { name: 'Sumit Zade', locate: 'Kolkata', category: 'Emergency', date: '04/12/2019', time: '3:30pm' },
            { name: 'Deepak Gupta', locate: 'Delhi', category: 'Emergency', date: '21/12/2019', time: '3:30pm' },
            { heading: 'Alok Sigh', locate: 'Uttar Pradesh', category: 'Emergency', date: '04/12/2019', time: '3:30pm' }
        ];
    }
    MessagePage.prototype.presentModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _deepakdummy_deepakdummy_component__WEBPACK_IMPORTED_MODULE_3__["DeepakdummyComponent"],
                            componentProps: { value: 123 }
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MessagePage.prototype.ngOnInit = function () {
    };
    MessagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-message',
            template: __webpack_require__(/*! ./message.page.html */ "./src/app/message/message.page.html"),
            styles: [__webpack_require__(/*! ./message.page.scss */ "./src/app/message/message.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], MessagePage);
    return MessagePage;
}());



/***/ })

}]);
//# sourceMappingURL=message-message-module.js.map