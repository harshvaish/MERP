(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["active-shooter-active-shooter-module"],{

/***/ "./src/app/active-shooter/active-shooter.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/active-shooter/active-shooter.module.ts ***!
  \*********************************************************/
/*! exports provided: ActiveShooterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActiveShooterPageModule", function() { return ActiveShooterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _active_shooter_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./active-shooter.page */ "./src/app/active-shooter/active-shooter.page.ts");







var routes = [
    {
        path: '',
        component: _active_shooter_page__WEBPACK_IMPORTED_MODULE_6__["ActiveShooterPage"]
    }
];
var ActiveShooterPageModule = /** @class */ (function () {
    function ActiveShooterPageModule() {
    }
    ActiveShooterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_active_shooter_page__WEBPACK_IMPORTED_MODULE_6__["ActiveShooterPage"]]
        })
    ], ActiveShooterPageModule);
    return ActiveShooterPageModule;
}());



/***/ }),

/***/ "./src/app/active-shooter/active-shooter.page.html":
/*!*********************************************************!*\
  !*** ./src/app/active-shooter/active-shooter.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\"  routerLink=\"/message\" ><ion-icon name=\"menu\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title>\n       Message\n      </ion-title>\n      \n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" > <ion-icon name=\"refresh\"></ion-icon> </button>\n      </ion-buttons>\n        \n    </ion-toolbar>\n  </ion-header>\n  \n  <ion-content>\n    <ion-card  class=\"emergency-box\" >\n      <ion-card-content>\n            <ion-grid>\n              <ion-row  class=\"text-center\"><h3 class=\"heading-title\">Urgent Message</h3></ion-row>\n                <ion-row class=\"text-center\">\n                   \n                    <ion-list class=\"full-width\">\n                         <ion-item >\n                          <ion-label>Active Shooter</ion-label>\n                          <ion-select >\n                              <ion-select-option>Emergency</ion-select-option>\n                              <ion-select-option>Active Shooter</ion-select-option>\n                              <ion-select-option>Intruder</ion-select-option>\n                            </ion-select>\n                        </ion-item> \n                      </ion-list>\n                  </ion-row>\n                  <ion-row  class=\"text-center\"><h3  class=\"heading-title\">Custom Message (Optional)</h3></ion-row>\n                  <ion-row>\n                     \n                      <ion-list  class=\"full-width\">\n                      \n                          <ion-item>\n                               <ion-input></ion-input>\n                            </ion-item>\n                        </ion-list>\n                        <button class=\"btn-50\" ion-button margin-right routerLink=\"/emergency\">\n                          Send Message\n                         </button>\n                    </ion-row>\n                      </ion-grid>\n                         </ion-card-content>\n    </ion-card>\n  \n  </ion-content>\n  "

/***/ }),

/***/ "./src/app/active-shooter/active-shooter.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/active-shooter/active-shooter.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n.emergency-box {\n  padding: 0px;\n  margin: 0;\n  background: #dd3333;\n  border-radius: 0;\n  text-align: center; }\n\n.heading-title {\n  font-size: 20px;\n  color: #000;\n  padding: 10px;\n  font-weight: bold; }\n\n.text-center h3 {\n  text-align: center;\n  width: 100%; }\n\n.full-width {\n  width: 100%;\n  border-radius: 5px; }\n\n.btn-50 {\n  width: 50%;\n  border-radius: 5px;\n  margin: 0 auto;\n  margin-top: 20px;\n  text-align: center;\n  padding: 10px;\n  border-top: 1px solid #989898;\n  background: #0d2a7a;\n  color: #fff;\n  height: 55px;\n  font-size: 18px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWN0aXZlLXNob290ZXIvRDpcXGlvbmljX3Byb2plY3RcXE1FUlBcXG1lcnAvc3JjXFxhcHBcXGFjdGl2ZS1zaG9vdGVyXFxhY3RpdmUtc2hvb3Rlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBUyw4QkFBOEIsRUFBQTs7QUFDdkM7RUFBZSxXQUFXO0VBQUMsZ0JBQWdCO0VBQUMsZUFBZSxFQUFBOztBQUMzRDtFQUFpQixZQUFZO0VBQUksU0FBUztFQUN0QyxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQUUsa0JBQWtCLEVBQUE7O0FBRXhDO0VBQWdCLGVBQWU7RUFBRSxXQUFXO0VBQUUsYUFBYTtFQUFFLGlCQUFpQixFQUFBOztBQUM5RTtFQUFpQixrQkFBa0I7RUFBRSxXQUFXLEVBQUE7O0FBQ2hEO0VBQWEsV0FBVztFQUFFLGtCQUFpQixFQUFBOztBQUMzQztFQUFTLFVBQVU7RUFBRSxrQkFBaUI7RUFBQyxjQUFjO0VBQUUsZ0JBQWdCO0VBQUUsa0JBQWtCO0VBQUUsYUFBYTtFQUFLLDZCQUE2QjtFQUFFLG1CQUFtQjtFQUFFLFdBQVc7RUFBRSxZQUFZO0VBQUMsZUFBZSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvYWN0aXZlLXNob290ZXIvYWN0aXZlLXNob290ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcnsgYmFja2dyb3VuZDogIzAzMTYzNyAhaW1wb3J0YW50O31cclxuLmhvbWUtaWNvbnsgICAgY29sb3I6ICNmZmY7YmFja2dyb3VuZDogbm9uZTtmb250LXNpemU6IDI2cHg7fVxyXG4uZW1lcmdlbmN5LWJveCB7IHBhZGRpbmc6IDBweDsgICBtYXJnaW46IDA7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZGQzMzMzO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMDsgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5oZWFkaW5nLXRpdGxleyBmb250LXNpemU6IDIwcHg7IGNvbG9yOiAjMDAwOyBwYWRkaW5nOiAxMHB4OyBmb250LXdlaWdodDogYm9sZDt9XHJcbi50ZXh0LWNlbnRlciBoM3sgdGV4dC1hbGlnbjogY2VudGVyOyB3aWR0aDogMTAwJTt9XHJcbi5mdWxsLXdpZHRoeyB3aWR0aDogMTAwJTsgYm9yZGVyLXJhZGl1czo1cHg7fVxyXG4uYnRuLTUweyB3aWR0aDogNTAlOyBib3JkZXItcmFkaXVzOjVweDttYXJnaW46IDAgYXV0bzsgbWFyZ2luLXRvcDogMjBweDsgdGV4dC1hbGlnbjogY2VudGVyOyBwYWRkaW5nOiAxMHB4OyAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzk4OTg5ODsgYmFja2dyb3VuZDogIzBkMmE3YTsgY29sb3I6ICNmZmY7IGhlaWdodDogNTVweDtmb250LXNpemU6IDE4cHg7fVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/active-shooter/active-shooter.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/active-shooter/active-shooter.page.ts ***!
  \*******************************************************/
/*! exports provided: ActiveShooterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActiveShooterPage", function() { return ActiveShooterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ActiveShooterPage = /** @class */ (function () {
    function ActiveShooterPage() {
    }
    ActiveShooterPage.prototype.ngOnInit = function () {
    };
    ActiveShooterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-active-shooter',
            template: __webpack_require__(/*! ./active-shooter.page.html */ "./src/app/active-shooter/active-shooter.page.html"),
            styles: [__webpack_require__(/*! ./active-shooter.page.scss */ "./src/app/active-shooter/active-shooter.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ActiveShooterPage);
    return ActiveShooterPage;
}());



/***/ })

}]);
//# sourceMappingURL=active-shooter-active-shooter-module.js.map