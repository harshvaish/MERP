(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.html":
/*!*************************************!*\
  !*** ./src/app/home/home.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"header\">\n       <ion-buttons slot=\"start\">\n        <button class=\"home-icon\" routerLink=\"/home\"  ><ion-icon name=\"home\"></ion-icon></button>\n    </ion-buttons>\n      <ion-title left>\n       Arodek\n      </ion-title>\n      <ion-buttons slot=\"end\">\n          <button class=\"home-icon\" routerLink=\"/icon-keys\" > <ion-icon name=\"help-circle\"></ion-icon> </button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" routerLink=\"/files\"><ion-icon name=\"filing\" ></ion-icon></button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\"  routerLink=\"/update-profile\"  ><ion-icon name=\"person\"></ion-icon></button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <button  class=\"home-icon\" routerLink=\"/login\"  ><ion-icon name=\"power\"></ion-icon></button>\n      </ion-buttons>\n      \n        \n    </ion-toolbar>\n  </ion-header>\n  <ion-content no-padding>\n      <ion-card>\n          <ion-card-content class=\"dashboard-box\" >\n                <ion-grid>\n                    <ion-row>\n                        <ion-col size=\"6\" size-lg  class=\"top-btn \">\n                            <button class=\"btn\" ion-button margin-right routerLink=\"/emergency\">\n                             EMERGENCY\n                            </button>\n                        </ion-col>\n                        <ion-col size=\"6\" size-lg  class=\"top-btn \">\n                            <button class=\"btn\" ion-button margin-right routerLink=\"/active-shooter\">\n                              ACTIVE SHOOTER\n                            </button>\n                        </ion-col>\n                      </ion-row>\n                      <ion-row>\n                          <ion-col size=\"6\" size-lg   class=\"btm-btn \">\n                              <button class=\"btn\" ion-button margin-right routerLink=\"/send-message\">\n                               SEND MESSAGE\n                              </button>\n                          </ion-col>\n                          <ion-col size=\"6\" size-lg  class=\" btm-btn\">\n                              <button class=\"btn\" ion-button margin-right routerLink=\"/message\">\n                                VIEW MESSAGE\n                              </button>\n                          </ion-col>\n                        </ion-row>\n                          </ion-grid>\n                             </ion-card-content>\n        </ion-card>\n  \n        <ion-grid>\n            <ion-row  *ngFor=\"let home of homecategory\">\n                <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                    <button class=\"btn\" ion-button margin-right routerLink=\"/{{home.href}}\">\n                     {{home.headingtitle}} \n                    </button>\n                </ion-col> \n              </ion-row>\n             \n             <!-- <ion-row>\n                  <ion-col size=\"12\" size-lg   class=\"nopadding\">\n                      <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                       TRANSPORTATION EMERGENCY PROCEDURE GUIDE\n                      </button>\n                  </ion-col> \n                </ion-row>\n               \n                <ion-row>\n                    <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                        <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                         BUILDING PERSONNEL PROCEDURE GUIDE\n                        </button>\n                    </ion-col> \n                  </ion-row>\n                 \n                  <ion-row>\n                      <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                          <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                            SAFE SCHOOL\n                          </button>\n                      </ion-col> \n                    </ion-row>\n                   \n                    <ion-row>\n                        <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                            <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                             TEST PLAN\n                            </button>\n                        </ion-col> \n                      </ion-row>\n                     \n                      <ion-row>\n                          <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                              <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                                TEST PLAN 2\n                              </button>\n                          </ion-col> \n                        </ion-row>\n                       \n                        <ion-row>\n                            <ion-col size=\"12\" size-lg   class=\"nopadding\">\n                                <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                                  TEST 3\n                                </button>\n                            </ion-col> \n                          </ion-row>\n                         \n                          <ion-row>\n                              <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                                  <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                                   TEST4\n                                  </button>\n                              </ion-col> \n                            </ion-row>\n                           \n                            <ion-row>\n                                <ion-col size=\"12\" size-lg  class=\"nopadding\" >\n                                    <button class=\"btn\" ion-button margin-right routerLink=\"/home\">\n                                     ABCD\n                                    </button>\n                                </ion-col> \n                              </ion-row>-->\n                             \n                              <img src=\"assets/img/logo-merp.png\">                                                                                     </ion-grid>\n   \n  </ion-content>\n  "

/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".btn {\n  width: 100%;\n  padding: 10px;\n  border-top: 1px solid #989898;\n  background: #0d2a7a;\n  color: #fff;\n  height: 55px;\n  font-size: 18px; }\n\n.footer-md:before {\n  background: none; }\n\n.dashboard-box {\n  padding: 0; }\n\n.nopadding {\n  padding: 0; }\n\n.btm-btn .btn {\n  background: #f3c100;\n  border-radius: 5px;\n  border-top: none; }\n\n.top-btn .btn {\n  background: #630d10;\n  border-radius: 5px;\n  border-top: none; }\n\n.header {\n  background: #031637 !important; }\n\n.home-icon {\n  color: #fff;\n  background: none;\n  font-size: 26px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcaW9uaWNfcHJvamVjdFxcTUVSUFxcbWVycC9zcmNcXGFwcFxcaG9tZVxcaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFBTSxXQUFXO0VBQUUsYUFBYTtFQUFLLDZCQUE2QjtFQUFFLG1CQUFtQjtFQUFFLFdBQVc7RUFBRSxZQUFZO0VBQUMsZUFBZSxFQUFBOztBQUNsSTtFQUFtQixnQkFBZ0IsRUFBQTs7QUFDbkM7RUFBZ0IsVUFBVSxFQUFBOztBQUMxQjtFQUFZLFVBQVUsRUFBQTs7QUFDdEI7RUFBZSxtQkFBa0I7RUFBRSxrQkFBaUI7RUFBQyxnQkFBZSxFQUFBOztBQUNwRTtFQUFlLG1CQUFrQjtFQUFFLGtCQUFpQjtFQUFDLGdCQUFlLEVBQUE7O0FBQ3BFO0VBQVMsOEJBQThCLEVBQUE7O0FBQ3ZDO0VBQWUsV0FBVztFQUFDLGdCQUFnQjtFQUFDLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5idG57IHdpZHRoOiAxMDAlOyBwYWRkaW5nOiAxMHB4OyAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzk4OTg5ODsgYmFja2dyb3VuZDogIzBkMmE3YTsgY29sb3I6ICNmZmY7IGhlaWdodDogNTVweDtmb250LXNpemU6IDE4cHg7fVxuLmZvb3Rlci1tZDpiZWZvcmV7IGJhY2tncm91bmQ6IG5vbmU7fVxuLmRhc2hib2FyZC1ib3h7IHBhZGRpbmc6IDA7fVxuLm5vcGFkZGluZ3sgcGFkZGluZzogMDt9XG4uYnRtLWJ0biAuYnRueyBiYWNrZ3JvdW5kOiNmM2MxMDA7IGJvcmRlci1yYWRpdXM6NXB4O2JvcmRlci10b3A6bm9uZTsgfVxuLnRvcC1idG4gLmJ0bnsgYmFja2dyb3VuZDojNjMwZDEwOyBib3JkZXItcmFkaXVzOjVweDtib3JkZXItdG9wOm5vbmU7fVxuLmhlYWRlcnsgYmFja2dyb3VuZDogIzAzMTYzNyAhaW1wb3J0YW50O31cbi5ob21lLWljb257ICAgIGNvbG9yOiAjZmZmO2JhY2tncm91bmQ6IG5vbmU7Zm9udC1zaXplOiAyNnB4O30iXX0= */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HomePage = /** @class */ (function () {
    function HomePage() {
        this.homecategory = [
            { headingtitle: 'EMERGENCY RESPONCE PLAN', href: 'emergency-responce-plan' },
            { headingtitle: 'TRANSPORTATION EMERGENCY PROCEDURE GUIDE' },
            { headingtitle: 'BUILDING PERSONNEL PROCEDURE GUIDE' },
            { headingtitle: 'SAFE SCHOOL' },
            { headingtitle: 'TEST PLAN' },
            { headingtitle: 'TEST PLAN 2' },
            { headingtitle: 'TEST 3' },
            { headingtitle: 'TEST 4' }
        ];
    }
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        })
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map